my, xnine and FuxiProductionsXP's new malware created with TFW# programming language (i created), visual studio, vbs to exe and vbscript
and yes the icon is bambi
enjoy :D